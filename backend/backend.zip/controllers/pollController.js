   // backend/controllers/pollController.js
   exports.getPolls = (req, res) => {
    res.send('Get all polls');
};

exports.createPoll = (req, res) => {
    res.send('Create a new poll');
};