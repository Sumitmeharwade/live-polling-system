import './App.css';
import Welcome from './components/Welcome';
import GettingStarted from './components/GettingStarted';
import GettingStartedStudent from './components/GettingStartedStudent';
import WaitingScreen from './components/WaitingScreen';
import QuestionScreen from './components/QuestionScreen';
import KickedOut from './components/KickedOut';
import PollHistory from './components/PollHistory';
function App() {
  return (
    <div className="App">

    {/* <Welcome></Welcome> */}
    {/* <GettingStarted></GettingStarted> */}
    {/* <GettingStartedStudent></GettingStartedStudent> */}
    {/* <WaitingScreen></WaitingScreen> */}
    {/* <QuestionScreen></QuestionScreen> */}
    <KickedOut></KickedOut>
    {/* <PollHistory></PollHistory> */}
    </div>
  );
}

export default App;
