import React from 'react';
import './WaitingScreen.css';

const WaitingScreen = () => {
  return (
    <div className="container">
      <div className="header">
        <span className="badge">🎤 Intervue Poll</span>
      </div>
      <div className="content">
        <img src="https://dashboard.codeparrot.ai/api/assets/Z09kP3FEV176CUtJ" alt="Loading" className="loading-icon" />
        <h1>Wait for the teacher to ask questions..</h1>
      </div>
      <div className="chat-bubble">
        <img src="https://dashboard.codeparrot.ai/api/assets/Z09kQHFEV176CUtK" alt="Chat" />
      </div>
    </div>
  );
};

export default WaitingScreen;
