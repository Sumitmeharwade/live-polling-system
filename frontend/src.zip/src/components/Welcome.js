import React from 'react';
import './Welcome.css';

function Welcome() {
  return (
    <div className="welcome-container">
      <div className="badge">Intervue Poll</div>
      <h1>Welcome to the <strong>Live Polling System</strong></h1>
      <p>Please select the role that best describes you to begin using the live polling system</p>
      <div className="roles">
        <div className="role-card selected">
          <h2>I’m a Student</h2>
          <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry</p>
        </div>
        <div className="role-card">
          <h2>I’m a Teacher</h2>
          <p>Submit answers and view live poll results in real-time.</p>
        </div>
      </div>
      <button className="continue-button">Continue</button>
    </div>
  );
}

export default Welcome;
