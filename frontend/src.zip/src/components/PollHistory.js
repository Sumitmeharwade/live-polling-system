import React from 'react';
import './PollHistory.css';

function PollHistory() {
  return (
    <div className="poll-history-container">
      <h1>View <strong>Poll History</strong></h1>
      
      {[1, 2].map((questionNumber) => (
        <div key={questionNumber} className="question-section">
          <h2>Question {questionNumber}</h2>
          <div className="question-box">
            <div className="question-title">
              Which planet is known as the Red Planet?
            </div>
            <div className="options">
              {[
                { number: 1, text: 'Mars', percentage: '75%' },
                { number: 2, text: 'Venus', percentage: '5%' },
                { number: 3, text: 'Jupiter', percentage: '5%' },
                { number: 4, text: 'Saturn', percentage: '15%' },
              ].map((option) => (
                <div key={option.number} className="option">
                  <div className="option-number">{option.number}</div>
                  <span>{option.text}</span>
                  <div className="percentage-bar" style={{ width: option.percentage }}></div>
                  <span className="percentage">{option.percentage}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      ))}

      <div className="chat-bubble">
        <img src="https://dashboard.codeparrot.ai/api/assets/Z1BcvMnfhe40mLfI" alt="Chat Bubble" />
      </div>
    </div>
  );
}

export default PollHistory;
