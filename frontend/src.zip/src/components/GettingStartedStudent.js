import React from 'react';
import './GettingStartedStudent.css';

function GettingStartedStudent() {
  return (
    <div className="student-container">
      <div className="badge">Intervue Poll</div>
      <h1>Let’s <strong>Get Started</strong></h1>
      <p>If you’re a student, you’ll be able to submit your answers, participate in live polls, and see how your responses compare with your classmates</p>
      
      <div className="name-section">
        <span>Enter your Name</span>
        <div className="name-box">
          <span>Rahul Bajaj</span>
        </div>
      </div>

      <button className="continue-button">Continue</button>
    </div>
  );
}

export default GettingStartedStudent;
