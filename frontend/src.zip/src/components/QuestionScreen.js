import React from 'react';
import './QuestionScreen.css';

function QuestionScreen() {
  return (
    <div className="question-container">
      <div className="question-header">
        <span>Question 1</span>
        <div className="timer">
          <img src="https://dashboard.codeparrot.ai/api/assets/Z1Bcu8nfhe40mLfH" alt="Timer" />
          <span className="time">00:15</span>
        </div>
      </div>
      <div className="question-box">
        <div className="question-title">
          Which planet is known as the Red Planet?
        </div>
        <div className="options">
          <div className="option selected">
            <div className="option-number">1</div>
            <span>Mars</span>
          </div>
          <div className="option">
            <div className="option-number">2</div>
            <span>Venus</span>
          </div>
          <div className="option">
            <div className="option-number">3</div>
            <span>Jupiter</span>
          </div>
          <div className="option">
            <div className="option-number">4</div>
            <span>Saturn</span>
          </div>
        </div>
      </div>
      <button className="submit-button">Submit</button>
      <div className="chat-bubble">
        <img src="https://dashboard.codeparrot.ai/api/assets/Z1BcvMnfhe40mLfI" alt="Chat Bubble" />
      </div>
    </div>
  );
}

export default QuestionScreen;
